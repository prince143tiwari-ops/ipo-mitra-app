import { Platform } from 'react-native';
import { requestPurchase, getProducts, finishTransaction } from 'react-native-iap';
import mobileAds, { RewardedAd, TestIds, AdEventType, RewardedAdEventType } from 'react-native-google-mobile-ads';

export const PREMIUM_PRICE_INR = 10;
export const PREMIUM_DAYS = 15;
export const REWARDED_MINUTES = 10;
export const PREMIUM_PRODUCT_ID = 'premium_10_15days';
export const PDF_DOWNLOAD_PRODUCT_ID = 'pdf_download_10';

// Test rewarded unit. Replace with your production AdMob rewarded unit after approval.
export const REWARDED_AD_UNIT_ID = __DEV__ ? TestIds.REWARDED : 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';

export async function initAds() {
  await mobileAds().initialize();
}

export function watchRewardedAd({ onReward, onClosed, onError }) {
  const ad = RewardedAd.createForAdRequest(REWARDED_AD_UNIT_ID);
  let rewarded = false;
  const unsubLoaded = ad.addAdEventListener(RewardedAdEventType.EARNED_REWARD, () => {
    rewarded = true;
    onReward?.(REWARDED_MINUTES);
  });
  const unsubClosed = ad.addAdEventListener(AdEventType.CLOSED, () => {
    unsubLoaded();
    unsubClosed();
    unsubError();
    onClosed?.(rewarded);
  });
  const unsubError = ad.addAdEventListener(AdEventType.ERROR, (err) => {
    unsubLoaded();
    unsubClosed();
    unsubError();
    onError?.(err);
  });
  ad.load();
  return () => { unsubLoaded(); unsubClosed(); unsubError(); };
}

export async function getPremiumProduct() {
  const products = await getProducts({ skus: [PREMIUM_PRODUCT_ID] });
  return products?.[0] || null;
}

export async function buyPaidPremium() {
  if (Platform.OS !== 'android' && Platform.OS !== 'ios') throw new Error('Supported on Android/iOS only');
  return requestPurchase({ skus: [PREMIUM_PRODUCT_ID] });
}

export async function finishPaidTransaction(purchase) {
  await finishTransaction({ purchase, isConsumable: false });
}

export async function buyPdfDownload() { return requestPurchase({ skus: [PDF_DOWNLOAD_PRODUCT_ID] }); }
export async function finishPdfTransaction(purchase) { await finishTransaction({ purchase, isConsumable: true }); }
