# IPO Mitra — Production Premium Integrations

## Premium rules
- Rewarded ad successfully completed: **10 minutes Premium**.
- Paid Google Play/App Store subscription/product: **₹10 for 15 days**.
- No paid tier above ₹10.
- Ad availability is controlled by the ad network; the app must never fake a reward when no reward event was received.

## 1. Rewarded Ads
The project uses `react-native-google-mobile-ads`.

Before release:
1. Create an AdMob app and Rewarded ad unit.
2. Put the real Android/iOS App IDs in `mobile/app.json`.
3. Replace the production rewarded unit in `mobile/premiumService.js`.
4. Keep Google test IDs during development/testing.
5. Build a native app (`expo prebuild` + Android/iOS build); Expo Go is not the production target for this native module.

## 2. ₹10 / 15-day purchase
Product ID: `premium_10_15days`

Create the product in Google Play Console with a price of ₹10 and configure it for a 15-day entitlement according to the current Play Console product model available to your account. The app must receive and verify the real purchase token before unlocking paid Premium.

For production, the backend must verify the token using Google Play Developer API credentials and then create the 15-day entitlement. Never trust a client-only premium flag.

## 3. Credentials still required from owner
Do not put these in source control:
- AdMob production App IDs / Rewarded ad unit IDs
- Google Play Console service-account JSON/private key
- Real API/data-provider key
- Production affiliate IDs

Use environment variables / secure CI secrets.

## 4. Safety
Never collect UPI PIN, bank password, OTP, trading password, or broker credentials. Never claim guaranteed IPO allotment, profit, or listing gain.
