
# Production integration checklist

## Google Play / App Store billing
Use the official store billing SDK in the mobile app.
Flow:
1. User taps ₹10 Premium.
2. Store checkout displays the actual final amount.
3. App receives purchase token/transaction.
4. App sends token to `/api/premium/purchase`.
5. Server verifies the purchase with the platform.
6. Only verified purchases receive paid entitlement.
7. Store acknowledgement/consumption rules must be followed.

Do not put store service-account credentials in the mobile app.

## Rewarded ads
Use an approved rewarded-ad SDK.
Only call `/api/premium/rewarded` after the SDK confirms a completed reward.
Do not grant premium merely because an ad was requested.

## Live IPO data
Implement a provider adapter that returns:
- source
- fetched_at
- last_updated
- verification status
- IPO status
- price band
- lot
- subscription by category
- official offer-document links
- allotment/registrar links where available

Do not scrape or republish data without permission. Keep GMP explicitly labelled unofficial.

## Firebase
Add Firebase/FCM credentials only through environment/secret management.
Recommended notifications:
- IPO opening
- IPO closing soon
- subscription update
- allotment information available
- listing day
- educational alerts
