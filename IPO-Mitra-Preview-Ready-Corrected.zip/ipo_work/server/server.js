require("dotenv").config();
const express=require("express"),cors=require("cors"),fs=require("fs"),path=require("path");
const {google}=require("googleapis");
const app=express(); app.use(cors()); app.use(express.json());
const DB=path.join(__dirname,"data.json");
const PORT=process.env.PORT||4000;
const ADMIN_TOKEN=process.env.ADMIN_TOKEN||"CHANGE_ME";
const PREMIUM_PRICE_INR=Number(process.env.PREMIUM_PRICE_INR||10);
const PREMIUM_DAYS=Number(process.env.PREMIUM_DAYS||15);
const REWARDED_PREMIUM_MINUTES=Number(process.env.REWARDED_PREMIUM_MINUTES||10);
const GOOGLE_PACKAGE_NAME=process.env.GOOGLE_PLAY_PACKAGE_NAME||"com.ipomitra.app";
const PREMIUM_PRODUCT_ID=process.env.PREMIUM_PRODUCT_ID||"premium_10_15days";
const PDF_DOWNLOAD_PRODUCT_ID=process.env.PDF_DOWNLOAD_PRODUCT_ID||"pdf_download_10";
const pdfEntitlements=new Map();
const pdfTokens=new Map();

function read(){return JSON.parse(fs.readFileSync(DB,"utf8"))}
function write(x){fs.writeFileSync(DB,JSON.stringify(x,null,2))}
function admin(req,res,next){const token=req.headers.authorization?.replace("Bearer ","");if(!token||token!==ADMIN_TOKEN)return res.status(401).json({error:"Unauthorized"});next();}

app.get("/api/health",(req,res)=>res.json({ok:true,time:new Date().toISOString()}));
app.get("/api/ipos",(req,res)=>res.json({items:read().ipos}));
app.get("/api/ipos/:id",(req,res)=>{const x=read().ipos.find(v=>String(v.id)===req.params.id);if(!x)return res.status(404).json({error:"Not found"});res.json(x);});
app.get("/api/premium",(req,res)=>res.json({price_inr:PREMIUM_PRICE_INR,paid_days:PREMIUM_DAYS,rewarded_minutes:REWARDED_PREMIUM_MINUTES,product_id:PREMIUM_PRODUCT_ID,auto_renew:false,hidden_charges:false}));

// In-memory rewarded entitlements for demo. Production should move this to a DB keyed by authenticated user.
const entitlements=new Map();
app.post("/api/premium/rewarded",(req,res)=>{const userId=String(req.body.userId||"");if(!userId)return res.status(400).json({error:"userId required"});const base=Math.max(Date.now(),entitlements.get(userId)?.expiresAt||0);const expiresAt=base+REWARDED_PREMIUM_MINUTES*60*1000;entitlements.set(userId,{type:"rewarded",expiresAt});res.json({ok:true,active:true,expiresAt});});

async function googlePlayClient(){
  const raw=process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON;
  if(!raw) throw new Error("GOOGLE_PLAY_SERVICE_ACCOUNT_JSON is not configured");
  const credentials=JSON.parse(raw);
  const auth=new google.auth.GoogleAuth({credentials,scopes:["https://www.googleapis.com/auth/androidpublisher"]});
  return google.androidpublisher({version:"v3",auth});
}

app.post("/api/premium/purchase/verify",async(req,res)=>{
  const userId=String(req.body.userId||"");
  const purchaseToken=String(req.body.purchaseToken||"");
  const productId=String(req.body.productId||PREMIUM_PRODUCT_ID);
  if(!userId||!purchaseToken)return res.status(400).json({error:"userId and purchaseToken required"});
  if(productId!==PREMIUM_PRODUCT_ID)return res.status(400).json({error:"Unknown premium product"});
  try{
    const androidpublisher=await googlePlayClient();
    const check=await androidpublisher.purchases.products.get({packageName:GOOGLE_PACKAGE_NAME,productId:PREMIUM_PRODUCT_ID,token:purchaseToken});
    const purchase=check.data;
    if(Number(purchase.purchaseState)!==0)return res.status(402).json({active:false,error:"Purchase is not completed"});
    const base=Math.max(Date.now(),entitlements.get(userId)?.expiresAt||0);
    const expiresAt=base+PREMIUM_DAYS*24*60*60*1000;
    entitlements.set(userId,{type:"paid",expiresAt,productId:PREMIUM_PRODUCT_ID});
    // Consume after successful verification so the same ₹10 product can be bought again later.
    await androidpublisher.purchases.products.consume({packageName:GOOGLE_PACKAGE_NAME,productId:PREMIUM_PRODUCT_ID,token:purchaseToken});
    res.json({ok:true,active:true,expiresAt,priceInr:PREMIUM_PRICE_INR,days:PREMIUM_DAYS});
  }catch(err){
    console.error("Google Play verification failed",err?.response?.data||err.message);
    res.status(503).json({active:false,error:"Purchase verification unavailable"});
  }
});
app.get("/api/premium/status",(req,res)=>{const e=entitlements.get(String(req.query.userId||""));res.json({active:!!e&&e.expiresAt>Date.now(),entitlement:e||null});});
app.get("/api/pdfs",(req,res)=>{const d=read();res.json({items:(d.education_pdfs||[]).filter(x=>x.published!==false)});});
app.get("/api/pdfs/:id",(req,res)=>{const x=(read().education_pdfs||[]).find(v=>String(v.id)===req.params.id);if(!x)return res.status(404).json({error:"Not found"});res.json({...x,pdf_url:undefined});});
app.get("/api/pdfs/:id/read-token",(req,res)=>{const userId=String(req.query.userId||"");const e=entitlements.get(userId);if(!e||e.expiresAt<=Date.now())return res.status(403).json({error:"Premium required"});const x=(read().education_pdfs||[]).find(v=>String(v.id)===req.params.id);if(!x)return res.status(404).json({error:"Not found"});const token="r_"+Date.now()+"_"+Math.random().toString(36).slice(2);pdfTokens.set(token,{id:x.id,type:"read",expiresAt:Date.now()+10*60*1000});res.json({ok:true,url:`/api/pdfs/${encodeURIComponent(x.id)}/read?token=${encodeURIComponent(token)}`});});
app.get("/api/pdfs/:id/read",(req,res)=>{const v=pdfTokens.get(String(req.query.token||""));if(!v||v.id!==req.params.id||v.type!=="read"||v.expiresAt<Date.now())return res.status(403).send("Read token expired");const x=(read().education_pdfs||[]).find(z=>String(z.id)===req.params.id);if(!x)return res.status(404).send("Not found");res.redirect(x.pdf_url);});
app.get("/api/pdfs/:id/download",(req,res)=>{const v=pdfTokens.get(String(req.query.token||""));if(!v||v.id!==req.params.id||v.type!=="download"||v.expiresAt<Date.now())return res.status(403).send("Download token expired");pdfTokens.delete(String(req.query.token||""));const x=(read().education_pdfs||[]).find(z=>String(z.id)===req.params.id);if(!x)return res.status(404).send("Not found");res.redirect(x.pdf_url);});
app.post("/api/pdf/purchase/verify",async(req,res)=>{const userId=String(req.body.userId||"");const purchaseToken=String(req.body.purchaseToken||"");const productId=String(req.body.productId||"");const pdfId=String(req.body.pdfId||"");if(!userId||!purchaseToken||!pdfId)return res.status(400).json({error:"userId, purchaseToken and pdfId required"});if(productId!==PDF_DOWNLOAD_PRODUCT_ID)return res.status(400).json({error:"Unknown PDF product"});const x=(read().education_pdfs||[]).find(v=>String(v.id)===pdfId);if(!x)return res.status(404).json({error:"PDF not found"});try{const androidpublisher=await googlePlayClient();const check=await androidpublisher.purchases.products.get({packageName:GOOGLE_PACKAGE_NAME,productId:PDF_DOWNLOAD_PRODUCT_ID,token:purchaseToken});const purchase=check.data;if(Number(purchase.purchaseState)!==0)return res.status(402).json({ok:false,error:"Purchase is not completed"});const key=`${userId}:${pdfId}`;pdfEntitlements.set(key,{purchasedAt:Date.now(),productId:PDF_DOWNLOAD_PRODUCT_ID});await androidpublisher.purchases.products.consume({packageName:GOOGLE_PACKAGE_NAME,productId:PDF_DOWNLOAD_PRODUCT_ID,token:purchaseToken});const token="d_"+Date.now()+"_"+Math.random().toString(36).slice(2);pdfTokens.set(token,{id:pdfId,type:"download",expiresAt:Date.now()+10*60*1000});res.json({ok:true,downloadUrl:`/api/pdfs/${encodeURIComponent(pdfId)}/download?token=${encodeURIComponent(token)}`,priceInr:x.download_price_inr||10});}catch(err){console.error("PDF purchase verification failed",err?.response?.data||err.message);res.status(503).json({ok:false,error:"Purchase verification unavailable"});}});


app.post("/api/admin/education-pdfs",admin,(req,res)=>{const d=read();const x={id:String(req.body.id||Date.now()),title:String(req.body.title||"Untitled PDF"),category:String(req.body.category||"Education"),description:String(req.body.description||""),pdf_url:String(req.body.pdf_url||""),download_price_inr:10,published:req.body.published!==false};if(!x.pdf_url)return res.status(400).json({error:"pdf_url required"});d.education_pdfs=d.education_pdfs||[];const i=d.education_pdfs.findIndex(v=>v.id===x.id);if(i>=0)d.education_pdfs[i]={...d.education_pdfs[i],...x};else d.education_pdfs.push(x);write(d);res.json(x);});
app.post("/api/admin/ipos",admin,(req,res)=>{const d=read(),item={id:Date.now(),...req.body};d.ipos.push(item);write(d);res.status(201).json(item);});
app.put("/api/admin/ipos/:id",admin,(req,res)=>{const d=read(),i=d.ipos.findIndex(v=>String(v.id)===req.params.id);if(i<0)return res.status(404).json({error:"Not found"});d.ipos[i]={...d.ipos[i],...req.body};write(d);res.json(d.ipos[i]);});
app.delete("/api/admin/ipos/:id",admin,(req,res)=>{const d=read();d.ipos=d.ipos.filter(v=>String(v.id)!==req.params.id);write(d);res.json({ok:true});});
app.post("/api/admin/sync",admin,(req,res)=>res.json({ok:true,mode:process.env.DATA_PROVIDER||"demo",message:"Provider adapter hook ready. Add a licensed/authorized data provider before enabling live sync."}));
app.listen(PORT,()=>console.log(`IPO Mitra API: http://localhost:${PORT}`));
