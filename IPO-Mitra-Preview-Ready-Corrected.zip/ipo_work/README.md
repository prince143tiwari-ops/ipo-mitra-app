
# IPO Mitra — Full Starter

## 1) Mobile
The `mobile/App.js` is an Expo React Native app.

Use Expo Snack:
- https://snack.expo.dev/
- Create a blank Expo project
- Replace App.js with `mobile/App.js`
- Change API constant in App.js to your deployed server URL.

## 2) Server
Requirements: Node.js 18+
```
cd server
npm install
npm start
```
API:
- GET /api/health
- GET /api/ipos
- GET /api/ipos/:id
- POST /api/admin/ipos
- PUT /api/admin/ipos/:id
- DELETE /api/admin/ipos/:id
- GET /api/settings
- PUT /api/settings

The included data.json contains DEMO data only.

## 3) Admin
Open `admin/index.html` in a browser while the server runs. For production, put this behind authentication and HTTPS.

## 4) Production data
Replace demo records with verified/licensed feeds. Store source + timestamp + status with every market-data field. Do not scrape or republish third-party data without permission.

## 5) Monetization
Configure approved affiliate URLs in the admin/settings layer. Clearly disclose commercial relationships. Add ads/premium only after testing the core app.

## 6) Compliance
This product is designed as investor education/information. Before publishing personalized "Apply/Avoid/Buy/Sell/Hold" recommendations or monetized research/advice, obtain professional legal/compliance review and determine applicable SEBI registration/obligations.

Never promise guaranteed allotment, guaranteed listing gains or guaranteed returns.


## Premium pricing model — ₹10 maximum

Recommended user-facing model:
- **₹10 Premium**: one low-cost premium purchase/subscription tier.
- **10-minute Rewarded Premium**: user watches a rewarded ad and gets 10 minutes of premium access.
- No premium tier above ₹10 in the app UI.
- No hidden auto-upgrade.
- Before real payment, show the exact final price and any applicable platform/tax charges.
- Premium entitlements should be verified server-side in production.

### Suggested economics
Free users:
- Core IPO/MF/NCD education
- Basic IPO information
- Basic calculators
- Ads

Premium ₹10:
- Advanced analysis
- Historical GMP/subscription charts
- Advanced calculators
- IPO comparison
- Ad-free premium session

Rewarded Ad:
- 10 minutes premium
- One rewarded ad per unlock
- Do not make the ad loop compulsory or deceptive.

### Important
The current build simulates payment/ad completion. A production app needs a real mobile payment/billing integration and a rewarded-ad SDK, plus server-side receipt/entitlement verification.


## FINAL PREMIUM UX

### Free
- IPO/MF/NCD education
- Basic IPO snapshot
- Basic calculators
- Ads

### ₹10 Premium
- One simple premium price point: ₹10 maximum
- No higher-priced tier in the product
- Advanced analysis/history/comparison tools
- Premium session can be ad-free

### Rewarded Premium
- Watch one rewarded ad
- Unlock premium for exactly 10 minutes
- After expiry, return automatically to Free
- The app should not force repeated ads or use deceptive ad interactions

### Real payment requirement
The package currently contains demo purchase behavior so the UI can be tested. Before Play Store/App Store release:
- Integrate the platform's official in-app purchase/billing system.
- Verify purchase receipts/tokens server-side.
- Display the final platform-confirmed price before purchase.
- Do not promise that ₹10 includes/avoids taxes or platform charges; show the actual checkout amount.
- Store only the minimum purchase/entitlement information needed.

### Real rewarded ads
Integrate an approved rewarded-ad SDK. Only grant the 10-minute pass after the SDK confirms a completed rewarded ad.


# Launch-ready additions

The package now includes:
- `.env.example` for server secrets
- Admin Bearer-token protection
- Billing verification endpoint placeholder
- Rewarded-ad entitlement endpoint
- Premium status endpoint
- Licensed data-provider sync hook
- Firebase/notification integration guide
- Store billing integration guide
- Admin token UI
- ₹10 max premium configuration
- 10-minute rewarded premium configuration

## What cannot be safely prefilled
Real Google Play/App Store merchant credentials, Firebase secrets, live market-data provider keys, and affiliate IDs belong to your accounts and must be added privately.


## Branding

Application name: **IPO Mitra**

Creator credit:
**Created by Priyanshu Tiwari**

Recommended display locations:
- Splash screen
- Home footer
- About/Profile
- App Store/Play Store developer-facing description where appropriate


## Updated Premium Model
- Rewarded ad completed: **10 minutes Premium** per successful reward.
- Paid Premium: **₹10 for 15 days**.
- Users never need to pay more than ₹10 for the paid Premium plan.
- Actual ad availability is subject to the ad network's serving limits/policies.

## Production Premium Integration
- Rewarded ad completion grants 10 minutes Premium.
- ₹10 Google Play/App Store purchase grants 15 days after server verification.
- Native AdMob + IAP hooks are included.
- Private AdMob/Play Console credentials are placeholders and must be configured by the owner.
See `PRODUCTION_SETUP.md` and `mobile/INTEGRATIONS.md`.
