# IPO Mitra — Production Setup

The premium flow is now wired as:

1. **Rewarded ad:** successful rewarded event → **10 minutes Premium**.
2. **Paid purchase:** Google Play product `premium_10_15days` → server verifies purchase → **15 days Premium for ₹10**.
3. Paid purchase is consumed only after successful server verification, allowing the ₹10 product to be purchased again later.

## What is already implemented
- Native Rewarded Ad integration (`react-native-google-mobile-ads`).
- Google Play billing integration (`react-native-iap`).
- Secure local device user ID (`expo-secure-store`).
- Server-side Google Play purchase verification hook.
- 15-day entitlement calculation.
- 10-minute rewarded entitlement calculation.
- No client-only paid entitlement is granted by the purchase button.

## Owner-only production credentials
These cannot be safely invented by ChatGPT and must be supplied/configured by the app owner:

- AdMob Android/iOS App IDs.
- Production Rewarded Ad Unit ID.
- Google Play Console product `premium_10_15days` priced at ₹10.
- Google Play Developer API service account with Android Publisher access.
- Production HTTPS API URL.

## Google Play setup
1. Create Android application with package `com.ipomitra.app` in Play Console.
2. Create a one-time in-app product named `premium_10_15days` and price it at ₹10.
3. Grant the backend service account access to the Play Console/Android Publisher API as required by Google.
4. Put the service-account JSON in the server secret `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON`.
5. Set `GOOGLE_PLAY_PACKAGE_NAME=com.ipomitra.app`.
6. Set `PREMIUM_PRODUCT_ID=premium_10_15days`.

## AdMob setup
1. Create the IPO Mitra app in AdMob.
2. Create a Rewarded ad unit.
3. Put real App IDs into `mobile/app.json`.
4. Put the real rewarded unit ID into `mobile/premiumService.js`.
5. During testing, keep Google's test rewarded ID; never click your own production ads.

## Build
This project uses native modules, so use a development/release build rather than Expo Go.

Typical flow:

```bash
cd mobile
npm install
npx expo prebuild
npx expo run:android
```

For Play Store release, build/sign an Android App Bundle using your normal EAS or Android release pipeline.

## Important
The ZIP intentionally contains placeholders for private credentials. It is **not possible to make a real Play Store charge or production AdMob account work without the owner's Play Console/AdMob credentials and store configuration**.
