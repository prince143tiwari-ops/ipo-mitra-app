# IPO Mitra Premium Policy

## Free rewarded-ad premium
- Every successfully completed rewarded ad grants **10 minutes of Premium access**.
- Users can repeat this whenever the ad network makes another rewarded ad available.
- The app must grant access only after the rewarded-ad SDK confirms a completed reward.
- Ad frequency/caps are controlled by the ad network and platform policies; the app cannot guarantee unlimited ad availability.

## Paid Premium
- **₹10 = 15 days Premium**
- No paid Premium tier above ₹10 is offered.
- Real Play Billing/App Store purchase verification is required before production entitlement is granted.

## Safety / compliance
- Premium access must not be represented as a guarantee of IPO allotment, profit, listing gains, or investment returns.
- Real ad SDK and store billing credentials must be configured before production release.
